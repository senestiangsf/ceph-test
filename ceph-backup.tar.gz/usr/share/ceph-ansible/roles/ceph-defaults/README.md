# Ansible role: ceph-defaults

Documentation is available at http://docs.ceph.com/ceph-ansible/.
