# Ansible role: ceph-container-engine

Documentation is available at http://docs.ceph.com/ceph-ansible/.
